title: Java-100位以上的整数运算(小垃圾只写出了加法)
date: '2020-09-07 14:33:07'
updated: '2020-09-07 15:02:24'
tags: [Java逻辑题]
permalink: /articles/2020/09/07/1599460387000.html
---
![](https://b3logfile.com/bing/20191023.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

```java
/**
     * 将通过它俩来进行运算
     */
    private int[] xints,yints;

    // 默认给两个字符串前面都加上一个零   为了解决两数相加多一位的问题
    public String add(String x,String y){
        return add(new StringBuffer(x).insert(0,"0"),new StringBuffer(y).insert(0,"0"));
    }


    /**
     * 加法操作
     * @param x :第一个数值
     * @param y :第二个数值
     * @return :返回x与y相加的结果
     */
    private String add(StringBuffer x,StringBuffer y){
        /**
         * c : 两个字符串之间的差值,用来持平长度
         * j : 两个int值的和,用来判断下一个是否进一
         */
        int c = x.length()-y.length(),j=0;
        StringBuffer temp = new StringBuffer("");
        for (int i = 0; i < Math.abs(c); i++) {
            //差值多大就补多少个0,方便相加
            temp.append(0);
        }
        //用来存储相加后的值(单个)
        List<Integer> sum = new ArrayList<>();

        //transitionInts : 返回最大长度(两个字符串)   并在内部将两个字符串拆分出两个int数组
        for (int i = transitionInts(x,y,c,temp) - 1,listIndex=0; i >= 0; i--,listIndex++) {
        //将两个值相加的结果添加到集合中   判断: 如果相加的结果大于9(进一)  则将上一个结果减10,当下的加1   
             sum.add(j =  (xints[i]+yints[i])+(j<9?0:sum.set(listIndex-1, j - 10).intValue()/10));
        }
        //将临时StringBuffer清空  等下来装最后的值
        temp.setLength(0);
        for (int i = sum.size()-1; i >=0 ; i--) {
            temp.append(sum.get(i));
        }
        return temp.toString();
    }

    /**
     *
     * @param s : 传入一个字符串将它变成Int数组
     * @return : Int数组
     */
    public int[] stringToInts(String s) {
        int[] ints = new int[s.length()];
        for (int i = 0; i < s.length(); i++) {
            ints[i] = Integer.parseInt(s.substring(i, i + 1));
        }
        return ints;
    }

    /**
     * 创建int数组
     * @param x
     * @param y
     */
    private Integer transitionInts(StringBuffer x,StringBuffer y,int c,StringBuffer temp){
       int max_Index = y.length();
        if(c>0){
            //最大长度
            max_Index = x.length();
            yints = stringToInts(temp.append(y).toString());
            xints = stringToInts(x.toString());
            return max_Index;
        }
        yints = stringToInts(y.toString());
        xints = stringToInts(temp.append(x).toString());
        return max_Index;
    }*
   
```

> #### 成功算出

![结果.png](https://b3logfile.com/file/2020/09/结果-38dfee50.png)
