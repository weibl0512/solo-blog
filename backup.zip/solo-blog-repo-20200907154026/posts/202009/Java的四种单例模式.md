title: Java的四种单例模式
date: '2020-09-01 14:36:47'
updated: '2020-09-01 14:36:47'
tags: [Java学习]
permalink: /articles/2020/09/01/1598942207677.html
---
![](https://b3logfile.com/bing/20200113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Java的四种单例模式

### 1 > 饿汉式(嗯...饿了吧唧的)  线程安全---> 刚出生就有了  你捣不了乱

```java
public class Singleton{
    //在实例化的直接创建一个对象(这孩子饿的不行)
    private final static Singleton instance = new Singleton();
    //私有化构造器
    private Singleton () { }
    // 只能通过方法来获取我的对象
    public static Singleton getInstance() {
        return instance;
  }
}
```

### 2 > 饿汉式(变种...饿出花样)

```java
pubic class Singleton {
     //这次在静态块中创建 因为静态块只能调用一次 就是类实例的时候调用
     private Singleton instance = null;
     static {
        instance = new Singleton;
     }
     //下面的和上一个一样
     private Singleton () {};
     public static Singleton getInstance() {
        return this.instance;
     }
 }
```

### 3 > 懒汉式(喜欢偷懒   你找我要我才给你)  线程不安全式

```java
public class Singleton{
        private static Singleton instance;
        private Singleton(){}
        //在你调用我这个方法的时候才创建,然后给你  但是这样会有线程安全问题
        public static Singleton getInstance(){
              if (instance == null) {
                  instance = new Singleton();
              }
              return instance;
       }
 }
```

### 4 > 懒汉式  线程安全式

```java

  public class Singleton{
        private static Singleton instance;
        private Singleton(){}
        //加了一个锁   当一个人找我要对象的时候其他人不能进来  要排队
        public static synchronized Singleton getInstance(){
              if (instance == null) {
                  instance = new Singleton();
              }
              return instance;
        }
 }
```
